package com.group7.minihouse.scheduler;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Bat co che @Scheduled cho cac job cua nhom (package scheduler). */
@Configuration
@EnableScheduling
public class SchedulerConfig {
}
