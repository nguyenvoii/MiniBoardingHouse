# MiniBoardingHouse (Nhóm 7)

Website quản lý nhà trọ mini. Công nghệ: Java 17, Spring Boot 3, Spring Data JPA, SQL Server.

## Cấu trúc package (`com.group7.minihouse`)

- `entity`: 56 class tương ứng 56 bảng trong `db/group-7.sql` (`UserRoleId` là khóa phức hợp, không phải entity)
- `repository`: Spring Data JPA repository
- `service`: xử lý nghiệp vụ
- `controller`: REST / web controller
- `dto`: đối tượng request/response
- `config`: cấu hình (bảo mật, web...)
- `util`: hàm tiện ích
- `exception`: exception tùy chỉnh

## Cách chạy

1. Chạy `db/group-7.sql` trên SQL Server.
2. Tạo file `src/main/resources/application-local.properties` (file này bị git ignore):
   ```
   spring.datasource.username=...
   spring.datasource.password=...
   ```
3. Chạy `mvn spring-boot:run` (`ddl-auto=validate` sẽ báo lỗi nếu entity lệch với DB).

## Phân công theo nhóm bảng

Mỗi người phụ trách một nhóm bảng (phân hệ DB): viết entity, repository, service, controller, dto cho các bảng đó.
Đặt tên file theo tên entity để không đụng nhau, ví dụ `RoomRepository`, `RoomService`, `RoomController`.
Nhóm bảng được gán theo người làm nhiều usecase nhất của phân hệ đó trong file Excel usecase.

| Thành viên | Mã SV | Số bảng | Số usecase | Package chung phụ trách |
|---|---|---|---|---|
| Nguyễn Anh Phi | TH08326 | 13 | 41 | `config` (bảo mật, đăng nhập, phân quyền) |
| Nguyễn Trần Bảo Chi | TH08666 | 15 | 32 | `util` (upload ảnh, gửi email, OTP SMS) |
| Phạm Khánh Toàn | TH08433 | 16 | 25 | job/scheduler (tự động chốt chỉ số, tính tiền, nhắc nợ) |
| Vũ Văn Quốc Việt | TH08548 | 12 | 25 | `exception`, xuất Excel/PDF, dashboard - báo cáo |

### 1. Nguyễn Anh Phi (13 bảng)
- Người dùng - phân quyền: `User`, `Role`, `Permission`, `UserRole` (+ `UserRoleId`)
- Khu trọ - phòng: `Property`, `PropertyFloor`, `Room`
- Hợp đồng: `RentalContract`
- Tính tiền tháng: `MonthlyBillingPeriod`, `CalculatedMonthlyFee`, `FeeItemDetail`
- Thanh toán: `PaymentTransaction`
- Bổ sung: `BankAccount`

### 2. Nguyễn Trần Bảo Chi (15 bảng)
- Người dùng: `UserVerification`, `UserActivityLog`
- Phòng: `RoomMedia`, `RoomFurnishing`
- Khách thuê - cư dân: `Tenant`, `TenantIdCard`, `RoomResident`, `ResidentStayHistory`
- Yêu cầu thuê - hợp đồng: `BookingRequest`, `ContractTemplate`, `ContractAdjustment`, `ContractNotification`
- Bổ sung: `TenantVehicle`, `NotificationTemplate`, `UserNotification`
- Usecase 1-2 (OTP email, SMS) cần API bên thứ ba, do Chi làm.

### 3. Phạm Khánh Toàn (16 bảng)
- Chỉ số điện nước: `UtilityReadingPeriod`, `MeterReading`, `MeterPhoto`, `MeterAdjustmentLog`, `MeterAnomalyAlert`
- Đơn giá - phí dịch vụ: `ServiceRatePlan`, `PropertyServiceRate`, `RoomCustomRate`, `RateChangeHistory`
- Hóa đơn: `Invoice`, `InvoiceNotification`
- Thu tiền - cấn trừ: `ReceiptVoucher`, `PartialPaymentLog`, `TenantPrepayment`, `PrepaymentDeduction`
- Bổ sung: `OperatingExpense`

#### Tiến độ của Toàn (code đã viết)

Tất cả API nằm dưới `/api`. Entity/bảng của người khác (Room, Property, User, Tenant, CalculatedMonthlyFee, PaymentTransaction...) được tham chiếu bằng `EntityManager`, không tạo thêm repository trùng tên với người khác.

| UC | Chức năng | Service | Endpoint chính |
|---|---|---|---|
| 53 | Tạo kỳ ghi chỉ số | `MeterReadingService` | `POST/GET /meter-periods`, `PATCH /meter-periods/{id}/closed` |
| 54, 55 | Nhập chỉ số, ảnh công tơ | `MeterReadingService` | `POST /meter-readings`, `POST /meter-readings/{id}/photos` |
| 56 | Xác nhận & điều chỉnh (kèm lý do) | `MeterReadingService` | `POST /meter-readings/{id}/confirm`, `PUT /meter-readings/{id}/adjust` |
| 57 | Cảnh báo tăng đột biến (>= 50% so với kỳ trước) | `MeterReadingService` + `BillingJobs` | `GET /meter-alerts`, `POST /meter-alerts/{id}/resolve` |
| 58, 59 | Lịch sử & so sánh tiêu thụ (dữ liệu biểu đồ) | `MeterReadingService` | `GET /rooms/{id}/consumption`, `GET /properties/{id}/consumption-comparison` |
| 60 | Chỉ số lúc vào / trả phòng | `MeterReadingService` | `POST /meter-readings/move-in`, `/move-out` |
| 61, 64 | Đơn giá điện nước, thời điểm áp dụng, lịch sử | `ServiceRateService` | `/service-rate-plans`, `/rate-histories` |
| 62 | Phí dịch vụ theo khu | `ServiceRateService` | `/property-service-rates` |
| 63 | Phụ thu / miễn giảm theo phòng (giá âm = miễn giảm) | `ServiceRateService` | `/room-custom-rates` |
| 76 | Tổng hợp tiền phải thu theo tháng / toàn khu | `InvoiceService` | `GET /invoices/summary`, `/invoices/summary/{yyyy-MM}` |
| 78 | Chi tiết hóa đơn, in | `InvoiceService` | `GET /invoices/{id}/detail`, `/invoices/{id}/print` |
| 79 | Phát hành hóa đơn (1 phòng / cả kỳ) + thông báo | `InvoiceService` | `POST /invoices`, `POST /invoices/batch` |
| 80, 81 | Gửi email, thông báo website, link chia sẻ | `InvoiceService` | `POST /invoices/{id}/send-email`, `/send-app`, `GET /invoices/share/{token}` |
| 82 | Nhắc trước hạn (3 ngày, 1 ngày) & báo quá hạn | `BillingJobs` (job 8h sáng) | tự động |
| 83 | Điều chỉnh hóa đơn + thông báo | `InvoiceService` | `PUT /invoices/{id}/total` |
| 84 | Tra cứu hóa đơn, hóa đơn cần thanh toán | `InvoiceService` | `GET /invoices`, `GET /invoices/payable` |
| 89 | Phiếu thu | `ReceiptService` | `POST/GET /receipts` |
| 90 | Xác nhận thanh toán, in biên nhận | `ReceiptService` | `POST /receipts/{id}/send-confirmation`, `/receipts/{id}/print` |
| 91 | Thanh toán một phần / nhiều lần | `PartialPaymentService` | `POST/GET /invoices/{id}/partial-payments`, `PUT /partial-payments/{id}` |
| 92 | Tiền dư: chuyển vào số dư, cấn trừ, hoàn tiền, hủy giao dịch sai | `PrepaymentService` | `/prepayments/*`, `POST /payment-transactions/{id}/reverse` |
| - | Chi phí vận hành (`OperatingExpense`) | `OperatingExpenseService` | `/operating-expenses` |

Ghi chú kỹ thuật:
- `scheduler/BillingJobs`: chốt kỳ ghi chỉ số quá hạn (1h sáng, trễ 7 ngày), nhắc hạn và báo quá hạn (8h sáng). Tắt bằng `minihouse.scheduler.enabled=false`.
- Gửi email thật: tạo 1 bean implements `InvoiceMailGateway` (Chi làm trong `util`). Chưa có bean thì thông báo email lưu trạng thái `PENDING`.
- Xuất PDF file: hiện có HTML in được (`/print`); Việt làm util xuất PDF chung thì gắn vào sau.
- Loại thông báo hóa đơn lưu trong cột `invoice_notifications.status` (`SENT`, `PENDING`, `REMINDER_BEFORE_DUE`, `OVERDUE_NOTICE`, `INVOICE_ADJUSTED`, `PAYMENT_CONFIRMED`) vì bảng không có cột loại riêng.
- Quy ước: `invoices.paid_amount` = tổng giao dịch SUCCESS + các đợt thanh toán một phần + cấn trừ. Phi cần cộng `paid_amount` khi ghi `PaymentTransaction` (UC 87) để khớp.
- Lỗi nghiệp vụ hiện dùng `ResponseStatusException`; Việt làm package `exception` thì đổi sang exception chung.

### 4. Vũ Văn Quốc Việt (12 bảng)
- Công nợ: `TenantDebt`, `DebtPenaltyLog`, `DebtReminder`, `DebtProcessingLog`
- Trả phòng - hoàn cọc - sự cố sửa chữa: `CheckoutRequest`, `CheckoutInspection`, `DepositRefundVoucher`, `MaintenanceRequest`, `MaintenanceLog`
- Bổ sung: `RoomEquipmentRequest`, `RoomAddonFee`, `IncidentCategory`

### Tổng kết

Phi 13 + Chi 15 + Toàn 16 + Việt 12 = 56 bảng, bằng số entity trong package `entity`.

8 bảng bổ sung (phân hệ 11 trong `group-7.sql`): `TenantVehicle` (Chi), `IncidentCategory` (Việt), `RoomEquipmentRequest` (Việt), `RoomAddonFee` (Việt), `OperatingExpense` (Toàn), `BankAccount` (Phi), `NotificationTemplate` (Chi), `UserNotification` (Chi).

Lưu ý: usecase 122 (sao lưu phục hồi dữ liệu) không cần bảng, Phi làm bằng chức năng của hệ quản trị/CSDL.

## Quy ước làm chung

- Mỗi thay đổi DB phải sửa `db/group-7.sql` VÀ entity tương ứng trong cùng 1 commit.
- Số class trong package `entity` phải bằng số bảng trong DB.
- Mỗi người làm trên branch riêng, ví dụ `phi/room`, `chi/tenant`, `toan/invoice`, `viet/debt`.
- Pull `main` trước khi bắt đầu làm và trước khi push.
- Làm xong thì tạo Pull Request vào `main`, không push thẳng lên `main`.
- Không sửa file entity của người khác; cần sửa thì nhắn người đó hoặc tạo PR.
